

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->

 <?php wp_footer(); ?>
<div class="footer">
    
</div>
    
    
</body>
</html>


