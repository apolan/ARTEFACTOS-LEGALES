var preguntas = [
    {id: 1, "titulo": "¿Eres abogado?", "descripcion": "",
        "opciones": [
            {label: "No", tipo: "texto", "function": "mngPregunta(1,2,'no')", style: "lst-option-small"},
            {label: "Si", tipo: "texto", "function": "mngPregunta(1,2,'si')", style: "lst-option-small"}
        ],
        styleA: "row section-menu-3 color-bkg-gray-1 color-txt-black", styleB: ""},
    {id: 2, "titulo": "¿Sabes qué es la SFC?", "descripcion": "",
        "opciones": [
            {label: "No", tipo: "texto", "function": "mngPregunta(2,3,'no')", style: "lst-option-small"},
            {label: "Si", tipo: "texto", "function": "mngPregunta(2,3,'si')", style: "lst-option-small"}
        ],
        styleA: "row section-menu-3 color-bkg-gray-1 color-txt-black", styleB: ""},
    {id: 3, "titulo": "¿Qué situación quieres explorar?", "descripcion": "",
        "opciones": [
            {label: "Información engañosa", tipo: "texto", "function": "mngPregunta(3,4,'info-enganosa')", style: "lst-option"},
            {label: "Cobro injustificado", tipo: "texto", "function": "mngPregunta(3,4,'info-cobro')", style: "lst-option"}
        ],
        styleA: "row section-menu-3 color-bkg-gray-1 color-txt-black", styleB: ""},
    {id: 4, "titulo": "¿Cuál es el tema relacionado?", "descripcion": "",
        "opciones": [
            {label: "Mi tarjeta de crédito", tipo: "texto", "function": "mngPregunta(4,5,'info-tc')", style: "lst-option"},
            {label: "Mi crédito libre inversión", tipo: "texto", "function": "mngPregunta(4,5,'info-li')", style: "lst-option"}
        ],
        styleA: "row section-menu-3 color-bkg-gray-1 color-txt-black", styleB: ""},
    {id: 5, "titulo": "¿Conoces cómo poner una denuncia o queja?", "descripcion": "",
        "opciones": [
            {label: "No, solo quiero conocer", tipo: "texto", "function": "mngPregunta(5,6,'no')", style: "lst-option"},
            {label: "Sí, pero no se cómo", tipo: "texto", "function": "mngPregunta(5,6,'si')", style: "lst-option"}
        ], styleA: "row section-menu-3 color-bkg-gray-1 color-txt-black", styleB: ""},
    {id: 6, "titulo": "¿Estas listo?", "descripcion": "",
        "opciones": [
            {label: "Explorar", tipo: "texto", "function": "mngPregunta(6,0,'explorar');activateGrap('cazador')", style: "lst-option"},
                    /* {label: "Organizador de Artefactos", tipo: "texto", "function": "activateGrap('cazador')", style: "lst-option"},*/
        ], styleA: "row section-menu-3 color-bkg-gray-1 color-txt-black", styleB: ""},
];



var complejidad = [
    {SHAPE: "N3", "TITULO": "Muy Alta", "DESCRIPCION": "Para leer y entender los contenidos te recomendamos ser asistido por un experto legal."},
    {SHAPE: "N4", "TITULO": "Alta", "DESCRIPCION": "El contenido puede ser leído y entendido pero para verificar el impacto legal necesitas ser asistido por un expero legal."},
    {SHAPE: "N5", "TITULO": "Normal", "DESCRIPCION": "Podrás entender la mayoría de conceptos legales y referencias dentro del documento."},
    {SHAPE: "N6", "TITULO": "aLGO", "DESCRIPCION": "Podrás entender la mayoría de conceptos legales y referencias dentro del documento."},
    {SHAPE: "N8", "TITULO": "Baja", "DESCRIPCION": "No necesitas "},
];