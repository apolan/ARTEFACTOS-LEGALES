var panelUi = [
{id: "mn-filter", "titulo": "¿Qué quieres saber?", "descripcion": "", icon: "", styleA: "mn-ui mn-ui-holder mn-bot-left", styleB: "", visible: "off",
        "help": {id: "modal-filter", "titulo": "Estructura tu búsqueda", "descripcion": "Selecciona la pregunta que quieres explorar y que te puede ayudar a entender los caminos que puedes tomar en tu situación.", "url": "", "function": "return;", style: "color-primary glyphicon glyphicon-eye-open pseudolink"},
        "childs": [
        {id: "f-1", label: "¿Cuál es la información vigente de mi consulta?", tipo: "tarjeta", "childs": [], "function": "linksConnect(\"información vigente\")", style: "row option-filter"},
                //{id: "f-2", label: "¿Bajo que condiciones puedo denunciar?", tipo: "tarjeta", "childs": [], "function": "linksConnect(\"\")'", style: "row option-filter"},
                        //{id: "f-3", label: "¿A que canales acudir por ayuda?", tipo: "tarjeta", "childs": [], "function": "setQuery(\"CANALES\")'", style: "row option-filter"},
                        {id: "f-4", label: "Explorar todo", tipo: "tarjeta", "childs": [], "function": "linksConnect(\"explorar\")", style: "row option-filter"},
                ],
                },
        {id: "mn-settings", "titulo": "Mi búsqueda", "descripcion": "", icon: "", styleA: "mn-ui mn-ui-holder mn-top-left", styleB: "", visible: "on",
                "help": {id: "modal-busqueda", "titulo": "Conoce sobre tus preguntas", "descripcion": "Es la forma en que se configura la visualización artefactos legales.", "url": "", "function": "return;", style: "color-primary glyphicon glyphicon-eye-open pseudolink"},
                "childs": [
                {id: "settingsList", label: "", tipo: "lista", "childs": [], "function": "", style: ""},
                ],
        },
        {id: "mn-legal", "titulo": "¿Quieres aumentar o disminuir <br>el nivel de complejidad?", "descripcion": "", icon: "", styleA: "mn-ui mn-ui-holder mn-top-right-2", styleB: "", visible: "off",
                "help": {id: "modal-legal", "titulo": "Nivel de complejidad", "descripcion": "Cada vez que cambias el nivel de complejidad puedes traducir la información más importante que se ajusta a tu búsqueda.<br><br>Al aumentar: el lenguaje que se utilizará será más técnico y se necesitará conocimientos expertos sobre el tema.<br><br>Al disminuir: el lenguaje que se utilizará será menos técnico y no  necesitará conocimientos expertos sobre el tema. <br>", "url": "", "function": "", style: "color-primary glyphicon glyphicon-eye-open pseudolink"},
                                "childs": [
                                {id: "", label: "Diminuir (-)", tipo: "tarjeta-small", "childs": [], "function": "actionComplejidad(\"+\");", style: "option-action btn-minus"},
                                {id: "", label: "Aumentar (+)", tipo: "tarjeta-small", "childs": [], "function": "actionComplejidad(\"-\");", style: "option-action btn-add"},
                                ],
                        },
                        /*{id: "mn-convencion", "titulo": "Convenciones", "descripcion": "", icon: "", styleA: "mn-ui mn-ui-holder mn-top-right-1", styleB: "", visible: "off",
                         "help": {id: "modal-convencion", "titulo": "Conocer sobre los artefactos", "descripcion": "Información Conocer sobre los artefactos", "url": "", "function": "", style: "color-primary glyphicon glyphicon-eye-open pseudolink"},
                         "childs": [
                         {id: "imgExplicacion", label: "", tipo: "img", "childs": [], "function": "", style: "img-explicacion", "url": "/img/lg-haptica-orange.png"},
                         ],
                         },*/
                        {id: "mn-visor", "titulo": "Visor", "descripcion": "", icon: "", styleA: "mn-ui mn-bot-right", styleB: "", visible: "off",
                                "help": {id: "modal-visor", "titulo": "Información detallada", "descripcion": "Visualiza la información en detalle del documento por el que estas interesado.", "url": "", "function": "", style: "color-primary glyphicon glyphicon-eye-open pseudolink"},
                                "childs": [
                                {id: "visor", label: "", tipo: "contenedor", "childs": [], "function": "", style: "mn-ui-visor", "url": ""},
                                ],
                        },
                        ];
