/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var settingsGraph = [
    {dominio: "color", tipo: "nodo", valueA: "NODO-0", valueB: "#c6e5ff8f"},
    {dominio: "color", tipo: "nodo", valueA: "NODO-1", valueB: "#c6e5ff"},
    {dominio: "color", tipo: "nodo", valueA: "NODO-2", valueB: "#c6e5ff"},
    {dominio: "color", tipo: "nodo", valueA: "NODO-3", valueB: "#c6e5ff"},
    {dominio: "color", tipo: "nodo", valueA: "NODO-4", valueB: "#c6e5ff"},
    {dominio: "color", tipo: "nodo", valueA: "ON", valueB: "#c6e5ff"},
    {dominio: "color", tipo: "link", valueA: "ON", valueB: "#c6e5ff"},
    {dominio: "stroke-width", tipo: "link", value: 4, value: "#c6e5ff"},
];



var query = "";

var indexPregunta = 0;
// 0 Nivel - Abogado
var paramCiudadano = 0;
// 0 Cobro
var paramTema = 0;
// 0 No quiero denunciar
var paramAccion = 0;
var uiPanels = [];
init();
function init() {
    loadFont("GothamBlack", "gtbck");
    loadFont("GothamBold", "gtbold");
    loadFont("GothamBook", "gtbook");
    loadFont("GothamLight", "gtlight");
    loadFont("GothamBook-Italic", "gtbooki");
    loadFont("CenturyGothicRegular", "cgregular");
    loadFont("CenturyGothicBold", "cgbold");
    loadFont("AdelleSansBold", "adllbold");
    loadFont("AdelleSansLight", "adllthin");
    loadFont("AdelleSansLight", "adlllight");
    loadFont("AdelleSansBook", "adllbook");
    loadFont("Chantal-Bold", "chantal-bold");
    loadFont("Chantal-BoldItalic.otf", "chantal-bold-italic");
    loadFont("Chantal-Light-Italic", "chantal-light-italic");
    loadFont("Chantal-Light", "chantal-light");
    loadFont("Chantal-Regular", "chantal-regular");
}

function loadFont(name, family) {
    var newStyle = document.createElement('style');
    newStyle.appendChild(document.createTextNode("\
    @font-face {\
        font-family: " + family + ";\
        src: url(" + urlcanonical + '/fonts/' + name + '.otf)' + ";\
    }\
    "));
    document.head.appendChild(newStyle);
}



function startGallery() {

    setTimeout(function () {

        var typed = new Typed("#vecino", {
            strings: premisas,
            typeSpeed: 40,
            backSpeed: 20,
            loop: true,
            shuffle: true,
            backDelay: 5000,
        });
    }
    , 2000);
}

/*
 * MANAGER PREGUTNAS
 */
function mngPregunta(id, nextId, value) {
    if (id == 1) {
        $("#p-" + id).hide();
        createPregunta(nextId);
        if (value == "si") {
            addConfig("abogado", "Soy abogado");
            paramCiudadano = 3;
        } else if (value == "no") {
            addConfig("abogado", "No soy abogado");
            paramCiudadano = 0;
        }
    } else if (id == 2) {
        $("#p-" + id).hide();
        createPregunta(nextId);
        if (value == "si") {
            addConfig("sfc", "Conozco a la SFC");
            if (paramCiudadano == 0) {
                paramCiudadano = 1;
            }
        } else if (value == "no") {
            addConfig("sfc", "No conozco a la SFC");
            paramCiudadano = 0;
        }
    } else if (id == 3) {
        $("#p-" + id).hide();
        createPregunta(nextId);
        if (value == "info-enganosa") {
            addConfig("info-enganosa", "Información engañosa");
        } else if (value == "info-cobro") {
            addConfig("info-cobro", "Cobro injustificado");
        }
    } else if (id == 4) {
        $("#p-" + id).hide();
        createPregunta(nextId);
        if (value == "info-tc") {
            addConfig("producto", "Mi tarjeta de crédito");
        } else if (value == "info-li") {
            addConfig("producto", "Mi crédito de libre inversión");
        }


    } else if (id == 5) {
        $("#p-" + id).hide();
        createPregunta(nextId);
        if (value == "si") {
            addConfig("denuncia", "No quiero denunciar");
        } else if (value == "no") {
            addConfig("denuncia", "Si quiero denunciar");
        }
    } else if (id == 6) {
        $("#p-" + id).hide();
        $('#dash').show();
        $('.section-pregunta').hide();
        $('.section-pregunta').hide();
        if (value == "explorar") {
            addConfig("explorar", "Explorar");
        }
    }
}
function addConfig(option, value) {
    $("#settingsList").append("<li class='txt-normal'>" + value + "</li>");
    // console.log(value);
}

/**
 * 
 * @param {type} id
 * @returns {undefined}
 */
function createPregunta(id) {

    var pregunta = getPreguntaById(id);
    var div = $('<div id="p-' + pregunta["id"] + '">').addClass(pregunta["styleA"]);
    var preguntaTxt = "";
    //console.log(pregunta);
    for (var opcion in pregunta["opciones"]) {
        preguntaTxt += '<li class="list-group-item txt-subtitulo-4 ' + pregunta["opciones"][opcion]["style"] + '" onclick="' + pregunta["opciones"][opcion]["function"] + '">' + pregunta["opciones"][opcion]["label"] + '</li>';
    }

    div.append('<div class="col-md-12"><p class="txt-subtitulo-0 text-center">'
            + pregunta["titulo"] + '</p> <p class="txt-normal-1 text-center">' + pregunta["descripcion"] +
            '</p><div class="row justify-content-center section-menu"><ul class="list-group list-group-horizontal ">' + preguntaTxt + ' </ul></div></div></div>');
    $("#preguntas").append(div);
}


function getPreguntaById(id) {

    for (var pregunta in preguntas) {
        if (preguntas[pregunta]["id"] == id) {
//console.log(preguntas[pregunta]);
            return preguntas[pregunta];
        }
    }
}


function initUI() {
    var modalTmp = "";
    for (var panel in panelUi) {
        var panelTmp = panelUi[panel];
        var divParent = "<div id='" + panelTmp["id"] + "' class='" + panelTmp["styleA"] + "'>" +
                "<div class='mn-config-title'><p class='txt-subtitulo-1-smll'>" + panelTmp["titulo"] +
                " <span class='" + panelTmp["help"]["style"] + "' title='" + panelTmp["help"]["titulo"] + "' data-toggle='modal' data-target='#" + panelTmp["help"]["id"] + "' onClick='" + panelTmp["help"]["function"] + "'></span>" +
                "</p></div>" +
                "[CHILDS]" +
                "</div>";
        // Crete modal

        modalTmp = "<div id='" + panelTmp["help"]["id"] + "' class='modal fade' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>" +
                "<div class='modal-dialog modal-dialog modal-dialog-centered'><div class='modal-content'>" +
                "<div class='modal-header'>" +
                "<h4 class='txt-subtitulo-3' modal-title' id='myModalLabel'> " + panelTmp["help"]["titulo"] + "</h4></div>" +
                "<div class='modal-body'> " +
                panelTmp["help"]["descripcion"] +
                "</div>" +
                "<div class='modal-footer'>" +
                "<button type='button' class='btn btn-default' data-dismiss='modal'>Entiendo</button>" +
                "</div></div></div></div>";
        var divChild = "";
        for (var child in panelTmp["childs"]) {
            var childTmp = panelTmp["childs"][child];
            //onsole.log(childTmp["tipo"]);
            //console.log(childTmp["tipo"]);
            if (childTmp["tipo"] == "tarjeta") {
                divChild += "<div id='" + childTmp["id"] + "' class='" + childTmp["style"] + "' onClick='" + childTmp["function"] + "'>" +
                        childTmp["label"] +
                        "</div>";
            } else if (childTmp["tipo"] == "tarjeta-small") {
                divChild += "<div id='" + childTmp["id"] + "' class='" + childTmp["style"] + "' onClick='" + childTmp["function"] + "'>" +
                        "<p>" + childTmp["label"] + "<p>" +
                        "</div>";
            } else if (childTmp["tipo"] == "lista") {
                divChild += "<ul id='" + childTmp["id"] + "' class='" + childTmp["style"] + "'></ul>";
            } else if (childTmp["tipo"] == "img") {
                divChild += "<img id='" + childTmp["id"] + "' class='" + childTmp["style"] + "' src='" + urlcanonical + childTmp["url"] + "'></img>";
            } else if (childTmp["tipo"] == "contenedor") {
//console.log(childTmp["tipo"]);
                divChild += "<div id='" + childTmp["id"] + "' class='" + childTmp["style"] + "'></div>";
            }
        }

// Reemplazo  de campos
//divChild = divChild.replace("[SUBCHILDS]", divSubChild);

        divParent = divParent.replace("[CHILDS]", divChild);
        uiPanels.push(panelTmp["id"]);
        $("#UI").append(divParent);
        $("#UI").append(modalTmp);
        if (panelTmp["visible"] == "off") {
            $("#" + panelTmp["id"]).hide();
        }
    }
}



function actionPanelOn() {
    for (var panelTmp in uiPanels) {
        /*if (uiPanels[panelTmp]["id"] == id)*/

        $("#" + uiPanels[panelTmp]).show();
    }
}







/*
 *  MANAGER GRAPGH
 */

var state = "none";
function activateGrap(action) {
    if (action === "none") {
        state = "none";
        location.reload();
    } else if (action === "cazador" && state !== "cazador") {

        state = "cazador";
        var src = urlcanonical + "/js/" + 'd3-symbol-extra.min.js';
        var srcD3 = 'http://d3js.org/d3.v5.min.js';
        var srcD3Multi = 'https://d3js.org/d3-selection-multi.v1.js';

        // $('<script>').attr('src', srcD3Multi).appendTo('head');
        $('<script>').attr('src', srcD3).appendTo('head');
        $('<script>').attr('src', src).appendTo('#panel-cazador');
        $("#panel-cazador").append("<svg width='1000' height='900'></svg>");
        setTimeout(
                function ()
                {
                    //alert(d3.version);
                    remap();
                    run();
                    actionPanelOn();
                    //initUI();
                    /*
                     $("#menu-filter").show();
                     
                     *
                     **/
                    //run2();
                }, 3000);
        //run();

    }
}
var baseSize = 100;

function remap() {

    grapN["nodes"] = ARTEFACTO_METADATA;
    var index = 0;

    for (var i in grapN["nodes"]) {
        //grapN["nodes"][i]["SERIAL"] = parseInt(grapN["nodes"][i]["SERIAL"]);
        grapN["nodes"][i]["ID"] = parseInt(grapN["nodes"][i]["FK_ARTEFACTO"]);
        grapN["nodes"][i]['SIZE'] = 1;
        grapN["nodes"][i]['SHAPE'] = "";

        if (grapN["nodes"][i]['SIZE'] <= 0) {
            grapN["nodes"][i]['SIZE'] = 100;
        }

        grapN["nodes"][i]["DEPENDENCIA"] = grapN["nodes"][i]["DEPENDENCIA"].split('|');
        grapN["nodes"][i]['IMPORTANCIA'] = 0;

    }


    // CALCULAR TAMAÑO
    for (var i in grapN["nodes"]) {
        var nodoTmp = grapN["nodes"][i];
        var tmpSize = 0;

        let p = nodoTmp['PAGINAS'];
        let d = nodoTmp['IMPORTANCIA'];
        let f = 0;
        nodoTmp['SIZE'] = baseSize * (p);


        if (d == 0) {
            nodoTmp['COLOR'] = "#e8e8e8";
        } else if (d == 1 || d == 1) {
            nodoTmp['COLOR'] = "#D6FCFF";
        } else if (d == 2 && d < 4) {
            nodoTmp['COLOR'] = "#8AF5FF";
        } else if (d == 3) {
            nodoTmp['COLOR'] = "#34F5FF";
        } else if (d >= 4) {
            nodoTmp['COLOR'] = "#00D6FF";
        }


        if (nodoTmp['SIZE'] >= 10000) {
            f = nodoTmp['SIZE'] * 0.02;
        } else if (nodoTmp['SIZE'] >= 20000) {
            f = nodoTmp['SIZE'] * 0.01;
        } else if (nodoTmp['SIZE'] >= 1000) {
            f = nodoTmp['SIZE'] * 0.005;
        } else if (nodoTmp['SIZE'] > 500 && nodoTmp['SIZE'] < 1000) {
            f = nodoTmp['SIZE'] * 0.05;
        } else if (nodoTmp['SIZE'] <= 500) {
            f = nodoTmp['SIZE'] * 0.25;
        } else {
            //f = 1;
        }

        nodoTmp['FORCE'] = f;
    }
}

var width = 1000;
var height = 1000;

var link, node, labelNode, label, color, container, svg, labelLayout, graphLayout, adjNodelist, arrowG, arrowWidth = 8, arrow;
var divTooltip;

var adjlist = [];

function run() {

    graph = grapN;

    color = d3.scaleOrdinal(d3.schemeCategory10);
    label = {
        'nodes': [],
        'links': []
    };

    adjlist = [];
    adjNodelist = [];

    svg = d3.select("svg").attr("width", width).attr("height", height);


    svg.append("defs").append("marker")
            .attr("id", "arrowhead")
            .attr("viewBox", "0 -5 10 10")
            .attr("refX", 13)
            .attr("refY", 0)
            .attr("markerUnits", "userSpaceOnUse")
            .attr("markerWidth", 12)
            .attr("markerHeight", 12)
            .attr("xoverflow", 'visible')
            .attr("orient", "auto")
            .append("path")
            .attr("d", "M0,-5L10,0L0,5")
            .attr('fill', "#333")
            ;


    container = svg.append("g");

    divTooltip = d3.select("body").append("div")
            .attr("class", "tooltip")
            .style("opacity", 0);



    svg.call(
            d3.zoom()
            .scaleExtent([.1, 4])
            .on("zoom", function () {
                container.attr("transform", d3.event.transform);
            })
            );

    labelLayout = d3.forceSimulation(label.nodes)
            .force("charge", d3.forceManyBody().strength(-50))
            .force("link", d3.forceLink(label.links).distance(0).strength(2));

    graphLayout = d3.forceSimulation(graph.nodes)
            .force("charge", d3.forceManyBody().strength(-10000))
            .force("center", d3.forceCenter(width / 2, height / 2))
            .force("x", d3.forceX(width / 2).strength(1))
            .force("y", d3.forceY(height / 2).strength(1))
            .force('collision', d3.forceCollide().radius(function (d) {
                return d.FORCE;
            }))
            .force("link", d3.forceLink(graph.links).id(function (d) {
                return d.ID;
            }).distance(100).strength(1))
            .on("tick", ticked);

    link = container.append("g").attr("class", "links")
            .selectAll(".line");

    node = container.append("g").attr("class", "nodes")
            .selectAll(".node");

    labelNode = container.append("g").attr("class", "labelNodes")
            .selectAll("text");

    /*arrow = container.append("g").selectAll("line");*/

    update();

}



function neigh(a, b) {
    return a == b || adjlist[a + "-" + b];
}

var update = function update() {

    node = node.data(graph.nodes, function (d) {
        //console.log(d.ID);

        //return d.ID;
    });
    // node = node.data(graph.nodes);
    node.exit().remove();

    node = node.enter()
            .append("path")
            .style("stroke", "#1e3a69ad")
            .style("stroke-width", 4)
            .style("fill", function (d) {
                var color;/*
                 if (d.NATURALEZA == "Ley") {
                 color = '#c6e5ff';
                 } else if (d.NATURALEZA == "Circular") {
                 color = '#c6e5ff';
                 } else {
                 color = '#c6e5ff';
                 }*/

                return d.COLOR;
            })
            .attr("r", function (d) {
                return d.SIZE
            })
            .attr("d", function (d) {
                var coder = getComplexByShape(d.CODIFICACION);
                //console.log("Coder:" + coder + " -" + d.ID);
                if (coder == "N3") {
                    symbol = d3.symbol().size(d.SIZE).type(d3.symbolTriangleLeft);
                } else if (coder == "N4") {
                    symbol = d3.symbol().size(d.SIZE).type(d3.symbolDiamondSquare);
                } else if (coder == "N5") {
                    symbol = d3.symbol().size(d.SIZE).type(d3.symbolPentagon);
                } else if (coder == "N6") {
                    symbol = d3.symbol().size(d.SIZE).type(d3.symbolHexagon);
                } else if (coder == "N8") {
                    symbol = d3.symbol().size(d.SIZE);
                } else {
                    console.log("ErroeCoder:" + d.CODIFICACION + " -" + d.ID);
                    symbol = d3.symbol().size(d.SIZE);
                }

                return symbol();
            }).merge(node);

    link = link.data(graph.links, function (d) {
        //return d.source.ID + "-" + d.target.ID;
    });
    link.exit().remove();

    link = link.enter()
            .append("line")
            .attr("stroke", "#aaa")
            .attr("stroke-width", "1px")
            .attr('marker-end', 'url(#arrowhead)')
            .merge(link);


    /*  arrow = arrow.data(graph.links);
     arrow.exit().remove();
     
     arrow = arrow.enter().append("line").attr("class", "arrow")
     .attr("marker-end", "url(#arrow)");
     //node.on("mouseover", focus).on("mouseout", unfocus);*/

    labelNode = labelNode.data(graph.nodes, function (d) {

    });

    labelNode.exit().remove();

    labelNode = labelNode.enter()
            .append("text")
            .text(function (d, i) {
                return d.NOMBRE;
            })
            .style("fill", "#555")
            .style("font-family", "Arial")
            .style("font-size", 12)
            .style("pointer-events", "none")
            .merge(labelNode); // to prevent mouseover/drag capture*/

//Actions mouse
    //node.on("mouseover", focus).on("mouseout", unfocus);
    node.on("click", focus)
            .on("mouseover", popUp)
            .on("mouseout", unPopUp);

    graphLayout.nodes(graph.nodes);

    graphLayout.force("link").links(graph.links);
    node.call(
            d3.drag()
            .on("start", dragstarted)
            .on("drag", dragged)
            .on("end", dragended)
            );
}


function ticked() {


    graph.nodes.forEach(function (d) {

        d.leftX = d.x + d.SIZE / 2;
        d.rightX = d.x - d.SIZE / 2;
        //.log(d);
    });

    node.attr("transform", function (d) {
        return "translate(" + d.x + "," + d.y + ")";
    });

    node.attr("transform", function (d) {
        return "translate(" + fixna(d.x) + "," + fixna(d.y) + ")";
    });


    // link.call(edge);
    link.attr("x1", function (d) {
        return d.source.x;
    }).attr("y1", function (d) {
        return d.source.y;
    }).attr("x2", function (d) {
        return d.target.x;
    }).attr("y2", function (d) {
        return d.target.y;
    });

    labelNode.attr("transform", function (d) {
        return "translate(" + fixna(d.x) + "," + fixna(d.y) + ")";
    });
}


function edge(selection) {
    selection.each(function (d) {
        //console.log(d);
        var sourceX, targetX, midX, dx, dy, angle;

        // This mess makes the arrows exactly perfect.
        if (d.source.rightX < d.target.leftX) {
            sourceX = d.source.rightX;
            targetX = d.target.leftX;
        } else if (d.target.rightX < d.source.leftX) {
            targetX = d.target.rightX;
            sourceX = d.source.leftX;
        } else if (d.target.isCircle) {
            targetX = sourceX = d.target.x;
        } else if (d.source.isCircle) {
            targetX = sourceX = d.source.x;
        } else {
            midX = (d.source.x + d.target.x) / 2;
            if (midX > d.target.rightX) {
                midX = d.target.rightX;
            } else if (midX > d.source.rightX) {
                midX = d.source.rightX;
            } else if (midX < d.target.leftX) {
                midX = d.target.leftX;
            } else if (midX < d.source.leftX) {
                midX = d.source.leftX;
            }
            targetX = sourceX = midX;
        }

        dx = targetX - sourceX;
        dy = d.target.y - d.source.y;
        angle = Math.atan2(dx, dy);

        // Compute the line endpoint such that the arrow
        // is touching the edge of the node rectangle perfectly.
        d.source.x = sourceX + Math.sin(angle) * d.SIZE;
        d.target.x = targetX - Math.sin(angle) * d.SIZE;
        d.source.y = d.source.y + Math.cos(angle) * d.SIZE;
        d.target.y = d.target.y - Math.cos(angle) * d.SIZE;
    })
            .attr("x1", function (d) {
                return d.source.x;
            })
            .attr("y1", function (d) {
                return d.source.y;
            })
            .attr("x2", function (d) {
                return d.target.x;
            })
            .attr("y2", function (d) {
                return d.target.y;
            });
}





function fixna(x) {
    if (isFinite(x))
        return x;
    return 0;
}

//function focus(d) {}
function focus(d) {
    $('.mn-closeFilter').remove();
    $('#UI').append("<div class='mn-closeFilter' ><p onClick='unfocus();'>Cerrar selección</p></div>")
    update();
    adjlist = [];
    adjNodelist = [];

    adjNodelist.push(d);
    /*var linkTmp = {"source": "ARTEFACT-1", "target": "ARTEFACT-2", "ID": 1};
     graph["links"].push(linkTmp);/*/
    var nodeTmp = d;
    graph.links.forEach(function (d) {

        adjlist[d.source.ID + "-" + d.target.ID] = true;
        //adjlist[nodeTmp.ID + "-" + d.source.ID] = true;

    });

    setVisor(d.ID);


    var index = d3.select(d3.event.target).datum().index;

    node.style("opacity", function (o) {
        find = false;

        if (o.ID == nodeTmp.ID) {
            find = true;

        } else if (adjlist[o.ID + "-" + nodeTmp.ID] || adjlist[nodeTmp.ID + "-" + o.ID]) {
            find = true;
        } else {
            find = false;
        }

        return find ? 1 : 0.1;
    });

    labelNode.attr("display", function (o) {
        //console.log("SEARCH:" + o.ID);

        if (o.ID == nodeTmp.ID) {
            find = true;

        } else if (adjlist[o.ID + "-" + nodeTmp.ID] || adjlist[nodeTmp.ID + "-" + o.ID]) {
            find = true;
        } else {
            find = false;
        }

        return find ? "block" : "none";


    });
    link.style("opacity", function (o) {
        return o.source.ID == d.ID || o.target.ID == d.ID ? 1 : 0.1;
    });
    //createLink("ARTIFACT-10", "ARTIFACT-10", "nodeA");*/
}


function unfocus() {
    $('.mn-closeFilter').remove();
    labelNode.attr("display", "block");
    node.style("opacity", 1);
    link.style("opacity", 1);
}

function popUp(d) {
    divTooltip.transition()
            .duration(200)
            .style("opacity", .9);
    divTooltip.html(
            "<p class='txt-normal-2'><span class='txt-normal-bold'>¿Quíen lo expidió?:</span><br>" + d.AGENTE + "</p>" +
            //"<p class='txt-normal-2'><span class='txt-normal-bold'>Tipo:</span> " + d.NATURALEZA + "|" + d.ID + " </p>"
            "<p class='txt-normal-2'><span class='txt-normal-bold'>Tipo:</span> " + d.NATURALEZA + " </p>"
            )
            .style("left", (d3.event.pageX) + "px")
            .style("top", (d3.event.pageY - 28) + "px");
}

function unPopUp(d) {
    divTooltip.transition()
            .duration(300)
            .style("opacity", 0);
}


function updateLink(link) {
    link.attr("x1", function (d) {
        return fixna(d.source.x);
    })
            .attr("y1", function (d) {
                return fixna(d.source.y);
            })
            .attr("x2", function (d) {
                return fixna(d.target.x);
            })
            .attr("y2", function (d) {
                return fixna(d.target.y);
            });
}

function changeComplex() {

}

function updateNode(node) {
    node.attr("transform", function (d) {
        return "translate(" + fixna(d.x) + "," + fixna(d.y) + ")";
    });
}

function dragstarted(d) {
    d3.event.sourceEvent.stopPropagation();
    if (!d3.event.active)
        graphLayout.alphaTarget(0.3).restart();
    d.fx = d.x;
    d.fy = d.y;
}

function dragged(d) {
    d.fx = d3.event.x;
    d.fy = d3.event.y;
}

function dragended(d) {
    if (!d3.event.active)
        graphLayout.alphaTarget(0);
    d.fx = null;
    d.fy = null;
}




function findNodeById(idNode) {
    for (var node in graph["nodes"]) {
        var nodeTmp = graph["nodes"][node];
        // console.log(nodeTmp);
        if (nodeTmp["ID"] == idNode) {
            return nodeTmp;
        }
    }
}

function createLink(nodeA, nodeB, action) {

    var linkTmp = {"source": nodeA, "target": nodeB, "ID": 1};
    graph["links"].push(linkTmp);
    adjlist = [];

    graph.links.forEach(function (d) {
        adjlist[d.source.ID + "-" + d.target.ID] = true;
        adjlist[d.target.ID + "-" + d.source.ID] = true;
    });
    updateData();

}



function deleteCard(node) {
    for (var i = 0; i < cards.length; i++) {
        if (node === cards[i]) {
            cards.splice(i, 1);
            return;
        }
    }
    $('#card-' + node).remove();
}


// Demonstration only, use d3.symbolSquare if a square is needed
var customSymbolSquare = {
    draw: function (context, size) {
        let s = Math.sqrt(size) / 2;
        context.moveTo(s, s);
        context.lineTo(s, -s);
        context.lineTo(-s, -s);
        context.lineTo(-s, s);
        context.closePath();
    }
};



function setVisor(id) {
    var item;
    console.log(id);
    for (var node in graph["nodes"]) {
        var nodeTmp = graph["nodes"][node];
        //console.log(nodeTmp);
        if (nodeTmp["ID"] == id) {
            item = nodeTmp;
        }
    }

    //let date = Date.parse(item["DT_CREACION"]);
    //date = new Date(date);
    //date = formatDate(date);
    //console.log(date);
    item["SHAPE"] = getComplexByShape(item["CODIFICACION"]);
    //console.log("shape:" + item["SHAPE"]);
    $(".visor-panel").remove();

    var divItem = "<div class='visor-panel'>" +
            "<div class='row line-bot'> " +
            "<div class='col-md-2'> " +
            "<div class='poly-parent'><img class='poly' src='" + urlcanonical + "/img/artefactos/" + "DUMMY"+ ".jpg'></div>" +
            "</div>" +
            "<div class='col-md-8'> " +
            "<p class='txt-normal-5'><span class='txt-normal-bold'>Nombre:</span> " + item["NOMBRE"] + "</p>" +
            "<p class='txt-normal-5'><span class='txt-normal-bold'>Tipo:</span> " + item["NATURALEZA"] + "</p>" +
            "<p class='txt-normal-5'><span class='txt-normal-bold'>Fecha de creación:</span> " + item["DT_CREACIÓN"] + "</p>" +
            //"<p class='txt-normal-5'><span class='txt-normal-bold'>¿Hace cuánto salió?:</span> " + calcDate(new Date(), date) + "</p>" +
            "</div>" +
            "</div>" +
            "<div class='row line-bot'> " +
            "<div class='col-md-2'> " +
            "<div class='poly-parent'><img class='poly' src='" + urlcanonical + "/img/" + getUrlFileByName(item["AGENTE"]) + "'></div>" +
            "</div>" +
            "<div class='col-md-8'> " +
            "<p class='txt-normal-5'><span class='txt-normal-bold'>¿Quíen lo expidió?: </span> " + item["AGENTE"] + "</p>" +
            "<p class='txt-normal-5'><span class='txt-normal-bold'>Consultar:</span> " + "URL" + "</p>" +
            "</div>" +
            "</div>" +
            "<div class='row line-bot'> " +
            "<div class='col-md-2'> " +
            "<div class='poly-parent'><img class='poly' src='" + urlcanonical + "/img/" + item["SHAPE"] + ".png'></div>" +
            "</div>" +
            "<div class='col-md-8'> " +
            "<p class='txt-normal-5'><span class='txt-normal-bold'>Número de páginas:</span> " + item["PAGINAS"] + "</p>" +
            //"<p class='txt-normal-2'><span class='txt-normal-bold'>Complejidad: </span> " + item["CODIFICACION"] + "</p>" +
            "</div>" +
            "</div>" +
            "<div class='row'> " +
            "<div class='col-md-12'> " +
            "<p class='txt-normal-2'><span class='txt-normal-bold'>Descripción para el ciudadano de a pie:<br></span> " + item["DESCRIPCION"] + "</p>" +
            "</div>" +
            "</div>";

//TO-DO: HISTORIALK
    $("#visor").append(divItem);
}


function getUrlFileByName(nombre) {

    for (var url in urlFiles) {
        if (urlFiles[url]["NOMBRE"] == nombre) {
            return urlFiles[url]["URL"];
        }
    }

    return "anonimo.png";
}


function getComplejidad(shape) {
    //console.log(shape);
    for (var complejidadTMP in complejidad) {

        if (complejidad[complejidadTMP]["SHAPE"] == shape) {
            //console.log(shape);
            return complejidad[complejidadTMP];
        }
    }
}


function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function formatDate(d) {
    var
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

    if (month.length < 2)
        month = '0' + month;
    if (day.length < 2)
        day = '0' + day;

    return [year, month, day].join('-');
}


function calcDate(date1, date2) {
    var diff = Math.floor(date1.getTime() - date2.getTime());
    var day = 1000 * 60 * 60 * 24;

    var days = Math.floor(diff / day);
    var months = Math.floor(days / 31);
    var years = Math.floor(months / 12);

    var message = "";
    message += months + " meses";

    return message;
}


function getSettingsGrapBy(dominio, tipo, valor) {

    for (var a in settingsGraph) {
        var tmpSetting = settingsGraphp[a];

        if (tmpSetting["dominio"] == dominio && tmpSetting["tipo"] == dominio && tmpSetting["valor"] == dominio) {
            return tmpSetting;
        }
    }

}

var disabled = false;

function actionComplejidad(action) {

    if (!disabled) {

        //console.log("init-" + paramCiudadano);
        if (action == '-') {

            if (paramCiudadano > 0) {
                paramCiudadano--;
            } else {
                return;
            }
        } else if (action == '+') {
            if (paramCiudadano <= 2) {
                paramCiudadano++;
            } else {
                return;
            }
        }
        //console.log("end-" + paramCiudadano);



        update();
        unfocus();

    }
}


function getComplexByShape(code) {
    console.log(code);
    if (paramCiudadano == 0) {
        return 'N3';
        // Todo lo ve facil
    } else if (paramCiudadano == 3) {
        return 'N8';
    } else if (paramCiudadano == 2) {

        if (code == 'Muy Bajo') {
            return 'N8';
        } else if (code == 'Bajo') {
            return'N8';
        } else if (code == 'Medio') {
            return 'N6';
        } else if (code == 'Alto') {
            return 'N4';
        } else if (code == 'Muy Alto') {
            return 'N3';
        }
    } else if (paramCiudadano == 1) {

        if (code == 'Muy Bajo') {
            return 'N8';
        } else if (code == 'Bajo') {
            return 'N5';
        } else if (code == 'Medio') {
            return 'N4';
        } else if (code == 'Alto') {
            return 'N3';
        } else if (code == 'Muy Alto') {
            return 'N3';
        }
    }
    console.log("error");
    return 'N8';
}


function linksConnect(action) {
    var index = 0;
    // no hay links
    if (action == "explorar") {
        $(".visor-panel").remove();
        graph.links = [];

        for (var i in grapN["nodes"]) {
            var nodoTmp = grapN["nodes"][i];
            var tmpSize = 0;

            let p = nodoTmp['PAGINAS'];
            let d = 0;
            let f = 0;
            nodoTmp['SIZE'] = baseSize * (p);


            if (d == 0) {
                nodoTmp['COLOR'] = "#e8e8e8";
            } else if (d == 1 || d == 1) {
                nodoTmp['COLOR'] = "#D6FCFF";
            } else if (d == 2 && d < 4) {
                nodoTmp['COLOR'] = "#8AF5FF";
            } else if (d == 3) {
                nodoTmp['COLOR'] = "#34F5FF";
            } else if (d >= 4) {
                nodoTmp['COLOR'] = "#00D6FF";
            }

            if (nodoTmp['SIZE'] >= 10000) {
                f = nodoTmp['SIZE'] * 0.02;
            } else if (nodoTmp['SIZE'] >= 20000) {
                f = nodoTmp['SIZE'] * 0.01;
            } else if (nodoTmp['SIZE'] >= 1000) {
                f = nodoTmp['SIZE'] * 0.005;
            } else if (nodoTmp['SIZE'] > 500 && nodoTmp['SIZE'] < 1000) {
                f = nodoTmp['SIZE'] * 0.05;
            } else if (nodoTmp['SIZE'] <= 500) {
                f = nodoTmp['SIZE'] * 0.25;
            } else {
                //f = 1;
            }

            nodoTmp['FORCE'] = f;
        }
    } else if (action == "denuncia") {
        $(".visor-panel").remove();
    } else if (action == "información vigente") {
        $(".visor-panel").remove();

// update links
        for (var i in grapN["nodes"]) {

            for (var tmp  in grapN["nodes"][i]["DEPENDENCIA"]) {
                if (grapN["nodes"][i]["DEPENDENCIA"][tmp] != "") {

                    grapN["links"].push({"source": grapN["nodes"][i]["ID"], "target": grapN["nodes"][i]["DEPENDENCIA"][tmp], "ID": index}, );
                    index++;
                }
            }
        }

// update nodos
        for (var i in grapN["links"]) {

            var nodoTMP = grapN["links"][i]["target"];
            //console.log("target:" + nodoTMP);

            for (var j in grapN["nodes"]) {
                if (grapN["nodes"][j]["ID"] == nodoTMP) {
                    //console.log(nodoTMP);
                    grapN["nodes"][j]["IMPORTANCIA"] = grapN["nodes"][j]["IMPORTANCIA"] + 1;
                    //console.log(grapN["nodes"][j]["IMPORTANCIA"]);
                }
            }
        }


        // CALCULAR TAMAÑO
        for (var i in grapN["nodes"]) {
            var nodoTmp = grapN["nodes"][i];
            var tmpSize = 0;

            let p = nodoTmp['PAGINAS'];
            let d = nodoTmp['IMPORTANCIA'];
            let f = 0;
            nodoTmp['SIZE'] = baseSize * (p);

            if (nodoTmp['SIZE'] >= 10000) {
                f = nodoTmp['SIZE'] * 0.02;
            } else if (nodoTmp['SIZE'] >= 20000) {
                f = nodoTmp['SIZE'] * 0.01;
            } else if (nodoTmp['SIZE'] >= 1000) {
                f = nodoTmp['SIZE'] * 0.005;
            } else if (nodoTmp['SIZE'] > 500 && nodoTmp['SIZE'] < 1000) {
                f = nodoTmp['SIZE'] * 0.05;
            } else if (nodoTmp['SIZE'] <= 500) {
                f = nodoTmp['SIZE'] * 0.25;
            } else {
                //f = 1;
            }

            if (d == 0) {
                nodoTmp['COLOR'] = "#e8e8e8";
                f = 0;
            } else if (d == 1 || d == 1) {
                nodoTmp['COLOR'] = "#D6FCFF";
            } else if (d == 2 && d < 4) {
                nodoTmp['COLOR'] = "#8AF5FF";
            } else if (d == 3) {
                nodoTmp['COLOR'] = "#34F5FF";
            } else if (d >= 4) {
                nodoTmp['COLOR'] = "#00D6FF";
            }



            nodoTmp['FORCE'] = f;
        }
    }

    update();
}