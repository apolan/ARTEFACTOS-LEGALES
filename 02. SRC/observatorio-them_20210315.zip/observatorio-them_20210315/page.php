<?php
get_header();
//session_start();
$_SESSION['login_user'] = $username;  // Initializing Session with value of PHP Variable
echo $_SESSION['login_user'];
?>

<?php ?>

<?php
if (have_posts()) : while (have_posts()) : the_post();
        get_template_part('content', get_post_format());

        $pagename = get_query_var('pagename');
        $contentPage = get_the_content();
        if ($pagename == "artefactos") {
            ?>

            <div  class="color-bkg-gray-1 section-pregunta">
                <div class="section-explicacion" >

                    <p class="text-center  txt-subtitulo-2">Antes de empezar...</p>
                    <p class="text-center txt-normal ">Para configurar tu experiencia por favor responde a las siguientes preguntas...</p>      
                </div>
                <div id="preguntas" class="d-flex align-items-center justify-content-center" >

                </div>
            </div>
            <!-- <div class="loader-4"><span></span></div> --> 
            <!-- > Paneles UI < --> 
            <div id="UI" > </div>

            <div id="dash" class="section-dashboard-1 justify-content-center">
                <div class="row">
                    <div class="col-xs-12 col-md-12">
                        <div class="col-xs-11">
                            <!-- Cazador Historias section -->
                            <div class="row panel justify-content-center border-separator">
                                <div class="space-md">
                                    <h2 class="txt-subtitulo-3 ">Territorio Financiero - Información detallada</h2>
                                    <div class="space-md"></div>
                                </div>
                            </div>
                            <div id="panel-cazador">                           
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <script>
                $('#dash').hide();
                $(".mn-ui-top").hide();
                $("#menu-filter").hide();
                initUI();
                indexPregunta = 1;
                createPregunta(indexPregunta);

            </script>
            <?php
        } elseif ($pagename == "bitacora") {
            ?>
            <div class="mn-bitacora">
                <p class="txt-subtitulo-2">Menu</p>
                <ul class="lst-bitacora">
                    <li><a href="#bitacora">Sobre el proyecto</a></li>
                    <li><a href="#sobreProyecto">Los Artefactos</a></li>
                    <ul>
                        <li><a href="#artefactosLegales">Artefactos legales</a></li>
                        <li><a href="#interfaces">Interfaces legales</a></li>
                    </ul>
                    <li><a href="#territorios">Territorios legales</a></li>
                    <ul>
                        <li>¿Qué es?</li>
                        <li>Territorio financiero</li>
                    </ul>

                    <li>Conjunto de datos</li>
                    <ul>
                        <li>Procesos</li>
                        <li>Descargar</li>
                    </ul>
                    <li>Bibliografía</li>
                </ul>
            </div>
            <div class="container" >

                <div class="row justify-content-center section-general"><a name="bitacora"></a>
                    <div class="col-sm-12 text-center text-center">
                        <h1  class="txt-titulo-proyecto text-center">
                            BITÁCORA<BR>
                        </h1>
                        <p class="txt-subtitulo-1 color-txt-gray text-center">Registro del proyecto</p> 
                        <p class="txt-subtitulo-3 color-txt-gray text-center">Fecha de actualización: 2020/12/15</p> 
                        <p class="space-lg"></p> 
                    </div>
                </div>
                <div class="row justify-content-center section-general"><a name="sobreProyecto"></a>
                    <div class="col-md-10">
                        <p class="txt-titulo-proyecto-2 left">
                            Sobre el proyecto
                        </p>
                    </div>
                </div>
                <div class="row justify-content-center section-general">
                    <div class="col-md-10">
                        <p class="txt-titulo-proyecto-2 left">
                            Los Artefactos
                        </p>
                    </div>
                </div>
                <div class="row justify-content-center section-general">
                    <div class="col-md-10">
                        <p class="txt-titulo-proyecto-2 left">
                            Territorios legales
                        </p>
                    </div>
                </div>
                <div class="row justify-content-center section-general">
                    <div class="col-md-10">
                        <p class="txt-titulo-proyecto-2 left">
                            Conjuntos de datos
                        </p>

                        <div class="row justify-content-center ">
                            <div class="col-md-12">
                                <p class="txt-subtitulo-2 left left">
                                    Recolección de datos
                                </p>
                            </div>
                        </div>
                        <div class="row justify-content-center ">
                            <div class="col-md-12">
                                <p class="txt-subtitulo-2 left left">
                                    Diagrama de datos (Artefactos legales)
                                </p>
                            </div>
                        </div>
                        <div class="row justify-content-center ">
                            <div class="col-md-12">
                                <p class="txt-subtitulo-2 left left">
                                    Script de modelado de datos CSV -> JSON
                                </p>
                            </div>
                        </div>
                        <div class="row justify-content-center ">
                            <div class="col-md-12">
                                <p class="txt-subtitulo-2 left left">
                                    Script de modelado de datos CSV - JSON
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="row justify-content-center section-general">
                    <div class="col-md-10">
                        <p class="txt-titulo-proyecto-2 left">
                            Bibliografía
                        </p>
                    </div>
                </div>
            </div>

            <?php
        }
    endwhile;
endif;
?>
<?php get_footer(); ?>